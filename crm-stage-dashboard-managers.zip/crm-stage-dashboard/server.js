// server.js (manager-aware)
const express = require('express');
const bodyParser = require('body-parser');
const Database = require('better-sqlite3');
const cors = require('cors');
const path = require('path');

// ===== Config =====
const PORT = process.env.PORT || 3000;
const STAGE_ORDER = (process.env.STAGE_ORDER ||
  'Цільовий лід,Отримано заміри,Надіслано КП,Повторний контакт,Дешевий сегмент,Очікуєм оплату,Аванс/оплату отримано,Успіх,Провал'
).split(',').map(s => s.trim()).filter(Boolean);

const PAID_STAGE    = process.env.PAID_STAGE    || 'Аванс/оплату отримано';
const SUCCESS_STAGE = process.env.SUCCESS_STAGE || 'Успіх';
const FAIL_STAGE    = process.env.FAIL_STAGE    || 'Провал';

const mustHave = new Set(STAGE_ORDER);
for (const term of [PAID_STAGE, SUCCESS_STAGE, FAIL_STAGE]) {
  if (!mustHave.has(term)) throw new Error(`Етап "${term}" має бути у STAGE_ORDER`);
}

const stageIndex = new Map(STAGE_ORDER.map((s, i) => [s, i]));
const knownStage = s => stageIndex.has(s);

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Optional token check
const SECRET = process.env.MAKE_TOKEN || null;
function authMw(req, res, next) {
  if (SECRET && req.headers['x-webhook-token'] !== SECRET) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

// ===== DB =====
const db = new Database('events.db');
db.pragma('journal_mode = WAL');

// deals now has manager
db.prepare(`
  CREATE TABLE IF NOT EXISTS deals (
    lead_id TEXT PRIMARY KEY,
    created_ts INTEGER NOT NULL,
    manager TEXT
  )
`).run();

// stage_events now has manager at time of event
db.prepare(`
  CREATE TABLE IF NOT EXISTS stage_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER NOT NULL,
    lead_id TEXT NOT NULL,
    old_stage TEXT,
    new_stage TEXT NOT NULL,
    manager TEXT
  )
`).run();

// Backward-compat: try add missing columns if DB existed before
try { db.prepare(`ALTER TABLE deals ADD COLUMN manager TEXT`).run(); } catch(e) {}
try { db.prepare(`ALTER TABLE stage_events ADD COLUMN manager TEXT`).run(); } catch(e) {}

db.prepare(`CREATE INDEX IF NOT EXISTS idx_deals_created ON deals(created_ts)`).run();
db.prepare(`CREATE INDEX IF NOT EXISTS idx_deals_manager ON deals(manager)`).run();
db.prepare(`CREATE INDEX IF NOT EXISTS idx_ev_lead_ts ON stage_events(lead_id, ts)`).run();
db.prepare(`CREATE INDEX IF NOT EXISTS idx_ev_new_stage ON stage_events(new_stage)`).run();
db.prepare(`CREATE INDEX IF NOT EXISTS idx_ev_manager ON stage_events(manager)`).run();

function toMillis(ts){
  if (!ts) return Date.now();
  if (typeof ts === 'number') return ts;
  const d = new Date(ts);
  return isNaN(d.getTime()) ? Date.now() : d.getTime();
}

// ===== Incoming webhooks =====

// 1) Deal created (cohort by creation date), include manager (відповідальний)
app.post('/deal', authMw, (req, res) => {
  const { lead_id, created_at, manager } = req.body || {};
  if (!lead_id) return res.status(400).json({ error: 'lead_id обовʼязковий' });
  const cts = toMillis(created_at);
  const row = db.prepare(`SELECT created_ts FROM deals WHERE lead_id=?`).get(String(lead_id));
  if (!row) {
    db.prepare(`INSERT INTO deals (lead_id, created_ts, manager) VALUES (?, ?, ?)`)
      .run(String(lead_id), cts, manager || null);
  } else if (manager) {
    // оновлюємо відповідального при потребі
    db.prepare(`UPDATE deals SET manager = COALESCE(?, manager) WHERE lead_id = ?`)
      .run(manager, String(lead_id));
  }
  return res.json({ ok: true });
});

// 2) Stage changed (moves by update date), include manager-at-event
app.post('/webhook', authMw, (req, res) => {
  const { lead_id, old_stage, new_stage, timestamp, created_at, manager } = req.body || {};
  if (!lead_id || !new_stage) return res.status(400).json({ error: 'lead_id і new_stage обовʼязкові' });
  if (!knownStage(new_stage)) return res.status(400).json({ error: `new_stage "${new_stage}" не у STAGE_ORDER`, STAGE_ORDER });

  const ts = toMillis(timestamp);
  db.prepare(`INSERT INTO stage_events (ts, lead_id, old_stage, new_stage, manager) VALUES (?, ?, ?, ?, ?)`)
    .run(ts, String(lead_id), old_stage || null, new_stage, manager || null);

  // If no /deal received earlier, insert now with created_at or ts and manager
  const row = db.prepare(`SELECT 1 FROM deals WHERE lead_id=?`).get(String(lead_id));
  if (!row) {
    const createdTs = created_at ? toMillis(created_at) : ts;
    db.prepare(`INSERT INTO deals (lead_id, created_ts, manager) VALUES (?, ?, ?)`)
      .run(String(lead_id), createdTs, manager || null);
  } else if (manager) {
    // keep deals.manager in sync if provided
    db.prepare(`UPDATE deals SET manager = COALESCE(?, manager) WHERE lead_id = ?`)
      .run(manager, String(lead_id));
  }

  return res.json({ ok: true });
});

// ===== Helpers =====
function parseDateRange(since, until) {
  let where = '', args = [];
  if (since) {
    const s = new Date(since + 'T00:00:00Z').getTime();
    where += (where ? ' AND ' : '') + ' >= ?';
    args.push(s);
  }
  if (until) {
    const u = new Date(until + 'T23:59:59Z').getTime();
    where += (where ? ' AND ' : '') + ' <= ?';
    args.push(u);
  }
  return { where, args };
}

// Distinct managers for UI
app.get('/managers', (req, res) => {
  const rows = db.prepare(`
    SELECT manager FROM deals WHERE manager IS NOT NULL
    UNION
    SELECT manager FROM stage_events WHERE manager IS NOT NULL
    ORDER BY manager
  `).all();
  res.json(rows.map(r => r.manager));
});

// ===== Metrics =====
app.get('/metrics', (req, res) => {
  const {
    created_since, created_until,
    updates_since, updates_until,
    manager,                 // filter value
    manager_mode = 'deal'    // 'deal' or 'event'
  } = req.query || {};

  // 1) Cohort by creation date (+ optional manager filter by deal owner)
  const cw = parseDateRange(created_since, created_until);
  let whereCreated = cw.where ? `WHERE d.created_ts ${cw.where}` : '';
  const argsCreated = [...cw.args];

  if (manager && manager_mode === 'deal') {
    whereCreated += (whereCreated ? ' AND ' : 'WHERE ') + ' d.manager = ?';
    argsCreated.push(manager);
  }

  const leads = db.prepare(`SELECT d.lead_id, d.created_ts, d.manager FROM deals d ${whereCreated}`).all(...argsCreated);

  if (leads.length === 0) {
    return res.json({
      stages: STAGE_ORDER,
      terminals: { PAID_STAGE, SUCCESS_STAGE, FAIL_STAGE },
      filters: { created_since, created_until, updates_since, updates_until, manager, manager_mode },
      cohort_size: 0,
      funnel_period: [],
      adjacent_conversions: [],
      branch_to_paid: [],
      branch_to_fail: [],
      totals_period: { paid: 0, success: 0, fail: 0 }
    });
  }

  const leadIds = leads.map(x => x.lead_id);
  const placeholders = leadIds.map(() => '?').join(',');

  // 2) All-time events for this cohort (to know "ever reached")
  let whereAll = `WHERE e.lead_id IN (${placeholders})`;
  const argsAll = [...leadIds];
  if (manager && manager_mode === 'event') {
    whereAll += ` AND e.manager = ?`;
    argsAll.push(manager);
  }
  const allRows = db.prepare(`
    SELECT e.ts, e.lead_id, e.old_stage, e.new_stage, e.manager
    FROM stage_events e
    ${whereAll}
    ORDER BY e.lead_id ASC, e.ts ASC
  `).all(...argsAll);

  const stageTimeEver = new Map(); // Map<lead_id, Map<stage, ts>>
  for (const r of allRows) {
    if (!knownStage(r.new_stage)) continue;
    if (!stageTimeEver.has(r.lead_id)) stageTimeEver.set(r.lead_id, new Map());
    const m = stageTimeEver.get(r.lead_id);
    if (!m.has(r.new_stage)) m.set(r.new_stage, r.ts);
  }

  const everSet = new Map(STAGE_ORDER.map(s => [s, new Set()]));
  for (const [lid, m] of stageTimeEver.entries()) {
    for (const st of m.keys()) everSet.get(st).add(lid);
  }

  // 3) Period events (moves by update date) + optional manager filter by event
  const uw = parseDateRange(updates_since, updates_until);
  let whereUpd = `WHERE e.lead_id IN (${placeholders})`;
  const argsUpd = [...leadIds];
  if (uw.where) { whereUpd += ` AND e.ts ${uw.where}`; argsUpd.push(...uw.args); }
  if (manager && manager_mode === 'event') { whereUpd += ` AND e.manager = ?`; argsUpd.push(manager); }

  const periodRows = db.prepare(`
    SELECT e.ts, e.lead_id, e.old_stage, e.new_stage, e.manager
    FROM stage_events e
    ${whereUpd}
    ORDER BY e.lead_id ASC, e.ts ASC
  `).all(...argsUpd);

  const stageTimeInPeriod = new Map(); // Map<lead_id, Map<stage, ts>>
  for (const r of periodRows) {
    if (!knownStage(r.new_stage)) continue;
    if (!stageTimeInPeriod.has(r.lead_id)) stageTimeInPeriod.set(r.lead_id, new Map());
    const m = stageTimeInPeriod.get(r.lead_id);
    if (!m.has(r.new_stage)) m.set(r.new_stage, r.ts);
  }

  const periodSet = new Map(STAGE_ORDER.map(s => [s, new Set()]));
  for (const [lid, m] of stageTimeInPeriod.entries()) {
    for (const st of m.keys()) periodSet.get(st).add(lid);
  }

  const funnelPeriod = STAGE_ORDER.map(st => ({
    stage: st,
    entered_in_period: periodSet.get(st).size
  }));

  const adjacent = [];
  for (let i = 0; i < STAGE_ORDER.length - 1; i++) {
    const from = STAGE_ORDER[i], to = STAGE_ORDER[i+1];
    const baseFrom = everSet.get(from).size || 0;
    const toInPeriod = periodSet.get(to).size || 0;
    const rate = baseFrom ? toInPeriod / baseFrom : 0;
    adjacent.push({
      from, to,
      base_from_ever: baseFrom,
      moved_to_in_period: toInPeriod,
      conversion_rate_period: Number(rate.toFixed(4))
    });
  }

  function branchTo(terminal) {
    const res = [];
    const termTimeInPeriod = new Map();
    for (const [lid, m] of stageTimeInPeriod.entries()) {
      const t = m.get(terminal);
      if (t != null) termTimeInPeriod.set(lid, t);
    }
    for (const st of STAGE_ORDER) {
      if (st === terminal) continue;
      const base = everSet.get(st).size || 0;
      let toTerm = 0;
      for (const [lid, tsTerm] of termTimeInPeriod.entries()) {
        const ever = stageTimeEver.get(lid) || new Map();
        const tsSt = ever.get(st);
        if (tsSt != null && tsSt <= tsTerm && stageIndex.get(st) <= stageIndex.get(terminal)) {
          toTerm++;
        }
      }
      res.push({
        stage: st,
        base_count_ever: base,
        to_terminal_in_period: toTerm,
        rate_to_terminal_period: base ? Number((toTerm/base).toFixed(4)) : 0
      });
    }
    return res;
  }

  const paidInPeriod    = periodSet.get(PAID_STAGE).size || 0;
  const successInPeriod = periodSet.get(SUCCESS_STAGE).size || 0;
  const failInPeriod    = periodSet.get(FAIL_STAGE).size || 0;

  res.json({
    stages: STAGE_ORDER,
    terminals: { PAID_STAGE, SUCCESS_STAGE, FAIL_STAGE },
    filters: { created_since, created_until, updates_since, updates_until, manager, manager_mode },
    cohort_size: leadIds.length,
    funnel_period: funnelPeriod,
    adjacent_conversions: adjacent,
    branch_to_paid: branchTo(PAID_STAGE),
    branch_to_fail: branchTo(FAIL_STAGE),
    totals_period: { paid: paidInPeriod, success: successInPeriod, fail: failInPeriod }
  });
});

// Static dashboard
app.use('/', express.static(path.join(__dirname, 'public')));

// Start
app.listen(PORT, () => {
  console.log(`→ http://localhost:${PORT}`);
  console.log(`Stages: ${STAGE_ORDER.join(' -> ')}`);
});
